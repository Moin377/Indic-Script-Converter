
import os
import pandas as pd
from .base import BaseIndoArabicTransliterator
from .str_mapper import StringTranslator

# Devanagari to Gujarati character mapping
DEVANAGARI_TO_GUJARATI_MAP = {
    'क': 'ક', 'ख': 'ખ', 'ग': 'ગ', 'घ': 'ઘ', 'ङ': 'ઙ',
    'च': 'ચ', 'छ': 'છ', 'ज': 'જ', 'झ': 'ઝ', 'ञ': 'ઞ',
    'ट': 'ટ', 'ठ': 'ઠ', 'ड': 'ડ', 'ढ': 'ઢ', 'ण': 'ણ',
    'त': 'ત', 'थ': 'થ', 'द': 'દ', 'ध': 'ધ', 'न': 'ન',
    'प': 'પ', 'फ': 'ફ', 'ब': 'બ', 'भ': 'ભ', 'म': 'મ',
    'य': 'ય', 'र': 'ર', 'ल': 'લ', 'व': 'વ', 'श': 'શ',
    'ष': 'ષ', 'स': 'સ', 'ह': 'હ', 'ळ': 'ળ', 'क्ष': 'ક્ષ',
    'त्र': 'ત્ર', 'ज्ञ': 'જ્ઞ',
    'अ': 'અ', 'आ': 'આ', 'इ': 'ઇ', 'ई': 'ઈ', 'उ': 'ઉ', 'ऊ': 'ઊ',
    'ए': 'એ', 'ऐ': 'ઐ', 'ओ': 'ઓ', 'औ': 'ઔ',
    'ा': 'ા', 'ि': 'િ', 'ी': 'ી', 'ु': 'ુ', 'ू': 'ૂ',
    'े': 'ે', 'ै': 'ૈ', 'ो': 'ો', 'ौ': 'ૌ', '्': '્'
}

devanagari_to_gujarati_translator = StringTranslator(DEVANAGARI_TO_GUJARATI_MAP)

def convert_devanagari_to_gujarati(text):
    return devanagari_to_gujarati_translator.translate(text)

class GujaratiTransliterator(BaseIndoArabicTransliterator):
    def __init__(self):
        super().__init__(consonants_map_files=['gujarati/consonants.csv'])

        # Optional: Load post-processing mappings
        try:
            postprocess_df = pd.read_csv(os.path.join(self.data_dir, 'gujarati/postprocess.csv'), header=None)
            self.gujarati_postprocess_map = {str(row[0]).strip(): str(row[1]).strip() for _, row in postprocess_df.iterrows()}
            self.gujarati_postprocessor = StringTranslator(self.gujarati_postprocess_map)
        except FileNotFoundError:
            self.gujarati_postprocessor = StringTranslator({})

    def transliterate_from_urdu_to_gujarati(self, text, nativize=False):
        """Convert Urdu-Arabic script text to Gujarati via Devanagari"""
        dev_text = super().transliterate_from_urdu_to_hindi(text, nativize=nativize)
        guj_text = convert_devanagari_to_gujarati(dev_text)
        guj_text = self.gujarati_postprocessor.translate(guj_text)
        return guj_text

    def transliterate_from_gujarati_to_urdu(self, text, nativize=False):
        """Convert Gujarati script back to Urdu-Arabic"""
        try:
            from indicnlp.transliterate.unicode_transliterate import UnicodeIndicTransliterator
            dev_text = UnicodeIndicTransliterator.transliterate(text, 'gu', 'hi')  # Gujarati → Devanagari
        except ImportError:
            # Fallback: simple reverse mapping
            dev_text = text
            for guj_char, dev_char in DEVANAGARI_TO_GUJARATI_MAP.items():
                dev_text = dev_text.replace(dev_char, guj_char)
        
        urdu_text = super().transliterate_from_hindi_to_urdu(dev_text, nativize=nativize)
        return urdu_text
