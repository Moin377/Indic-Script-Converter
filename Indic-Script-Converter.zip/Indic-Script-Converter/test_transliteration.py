
#!/usr/bin/env python3
"""
Test script to demonstrate Indo-Arabic transliteration functionality
"""

from indo_arabic_transliteration.mapper import script_convert
from indo_arabic_transliteration.sangam_api import online_transliterate

def test_rule_based_conversion():
    print("=== Rule-based Conversion Examples ===")
    
    # Hindi-Urdu (Hindustani)
    print("\n1. Hindi-Urdu Conversion:")
    hindi_text = "हैदराबाद"
    urdu_text = "حیدرآباد"
    
    print(f"Hindi to Urdu: {hindi_text} → {script_convert(hindi_text, 'hi-IN', 'ur-PK')}")
    print(f"Urdu to Hindi: {urdu_text} → {script_convert(urdu_text, 'ur-PK', 'hi-IN')}")
    
    # Punjabi
    print("\n2. Punjabi Conversion:")
    gurmukhi_text = "ਸਿੰਘ"
    shahmukhi_text = "سنگھ"
    
    print(f"Gurmukhi to Shahmukhi: {gurmukhi_text} → {script_convert(gurmukhi_text, 'pa-IN', 'pa-PK')}")
    print(f"Shahmukhi to Gurmukhi: {shahmukhi_text} → {script_convert(shahmukhi_text, 'pa-PK', 'pa-IN')}")
    
    # Sindhi
    print("\n3. Sindhi Conversion:")
    sindhi_dev = "हैदराबाद"
    sindhi_arab = "حیدرآباد"
    
    print(f"Sindhi Devanagari to Arabic: {sindhi_dev} → {script_convert(sindhi_dev, 'sd-IN', 'sd-PK')}")
    print(f"Sindhi Arabic to Devanagari: {sindhi_arab} → {script_convert(sindhi_arab, 'sd-PK', 'sd-IN')}")

def test_online_api():
    print("\n=== Sangam API Examples (requires internet) ===")
    
    try:
        hindi_text = "हैदराबाद"
        urdu_text = "حیدرآباد"
        
        print(f"Online Hindi to Urdu: {hindi_text} → {online_transliterate(hindi_text, 'hi-IN', 'ur-PK')}")
        print(f"Online Urdu to Hindi: {urdu_text} → {online_transliterate(urdu_text, 'ur-PK', 'hi-IN')}")
        
    except Exception as e:
        print(f"Online API error: {e}")

def interactive_test():
    print("\n=== Interactive Test ===")
    print("Available language codes:")
    print("  hi-IN (Hindi Devanagari)")
    print("  ur-PK (Urdu Perso-Arabic)")
    print("  pa-IN (Punjabi Gurmukhi)")
    print("  pa-PK (Punjabi Shahmukhi)")
    print("  sd-IN (Sindhi Devanagari)")
    print("  sd-PK (Sindhi Perso-Arabic)")
    
    while True:
        text = input("\nEnter text to convert (or 'quit' to exit): ").strip()
        if text.lower() == 'quit':
            break
            
        from_script = input("From language code: ").strip()
        to_script = input("To language code: ").strip()
        
        try:
            result = script_convert(text, from_script, to_script)
            print(f"Result: {result}")
        except Exception as e:
            print(f"Error: {e}")

if __name__ == "__main__":
    print("Indo-Arabic Transliteration Test")
    print("=" * 40)
    
    test_rule_based_conversion()
    test_online_api()
    interactive_test()
